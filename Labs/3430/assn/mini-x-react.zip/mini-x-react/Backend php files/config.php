<?php
// WeatherStack API key
define('WEATHERSTACK_API_KEY', 'dd862bc96098752de7d377dcbde5f1e7');
?>
